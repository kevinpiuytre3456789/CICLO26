import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Calendar, Clock, User, X, RefreshCw } from 'lucide-react';

const appts = [
  { id: 1, doctor: 'Dr. Eduardo Vega', specialty: 'Cardiología', date: '20 sep 2026', time: '10:00 AM', status: 'Confirmada', group: 'upcoming' },
  { id: 2, doctor: 'Dra. Patricia López', specialty: 'Med. General', date: '05 oct 2026', time: '09:30 AM', status: 'Solicitada', group: 'upcoming' },
  { id: 3, doctor: 'Dr. Eduardo Vega', specialty: 'Cardiología', date: '13 sep 2026', time: '09:00 AM', status: 'Finalizada', group: 'past' },
  { id: 4, doctor: 'Dr. Eduardo Vega', specialty: 'Cardiología', date: '12 ago 2026', time: '09:00 AM', status: 'Finalizada', group: 'past' },
  { id: 5, doctor: 'Dra. Patricia López', specialty: 'Med. General', date: '18 jul 2026', time: '10:30 AM', status: 'No asistió', group: 'past' },
  { id: 6, doctor: 'Dr. Eduardo Vega', specialty: 'Cardiología', date: '01 jul 2026', time: '09:00 AM', status: 'Cancelada', group: 'cancelled' },
];

const statusBadge: Record<string, string> = {
  'Confirmada': 'bg-blue-100 text-blue-700',
  'Solicitada': 'bg-slate-100 text-slate-600',
  'Finalizada': 'bg-green-100 text-green-700',
  'Cancelada': 'bg-red-100 text-red-700',
  'No asistió': 'bg-orange-100 text-orange-700',
};

export default function PatientAppointments() {
  const navigate = useNavigate();
  const [tab, setTab] = useState<'upcoming' | 'past' | 'cancelled'>('upcoming');
  const filtered = appts.filter(a => a.group === tab);

  return (
    <div className="p-6 max-w-screen-md">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-xl font-bold text-slate-900" style={{ fontFamily: 'DM Sans, sans-serif' }}>Mis citas</h1>
        <button className="btn btn-primary btn-sm" onClick={() => navigate('/admin/book')}>
          <Calendar size={13} />
          Agendar cita
        </button>
      </div>

      <div className="flex gap-1 mb-5">
        {[
          { key: 'upcoming', label: 'Próximas' },
          { key: 'past', label: 'Anteriores' },
          { key: 'cancelled', label: 'Canceladas' },
        ].map(t => (
          <button
            key={t.key}
            className={`tab-btn ${tab === t.key ? 'active' : ''}`}
            onClick={() => setTab(t.key as any)}
          >
            {t.label}
          </button>
        ))}
      </div>

      {filtered.length === 0 ? (
        <div className="card p-12 text-center">
          <Calendar size={32} className="text-slate-300 mx-auto mb-3" />
          <div className="text-slate-500 text-sm">No hay citas registradas.</div>
        </div>
      ) : (
        <div className="space-y-3">
          {filtered.map(a => (
            <div key={a.id} className="card p-4">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-xl bg-blue-600 text-white flex flex-col items-center justify-center flex-shrink-0">
                  <div className="text-xs font-medium">{a.date.split(' ')[1]}</div>
                  <div className="text-base font-bold leading-tight" style={{ fontFamily: 'DM Sans, sans-serif' }}>{a.date.split(' ')[0]}</div>
                </div>
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-sm font-semibold text-slate-900">{a.doctor}</span>
                    <span className={`badge text-xs ${statusBadge[a.status]}`}>{a.status}</span>
                  </div>
                  <div className="flex flex-wrap gap-3 text-xs text-slate-500">
                    <span className="flex items-center gap-1"><User size={11} /> {a.specialty}</span>
                    <span className="flex items-center gap-1"><Clock size={11} /> {a.time}</span>
                    <span className="flex items-center gap-1"><Calendar size={11} /> {a.date}</span>
                  </div>
                </div>
                {a.group === 'upcoming' && (
                  <div className="flex gap-2">
                    <button className="btn btn-secondary btn-sm text-xs">
                      <RefreshCw size={11} />
                      Reprogramar
                    </button>
                    <button className="btn btn-danger btn-sm text-xs">
                      <X size={11} />
                      Cancelar
                    </button>
                  </div>
                )}
                {a.group === 'past' && (
                  <button className="btn btn-ghost btn-sm text-blue-600 text-xs">Ver resumen</button>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
