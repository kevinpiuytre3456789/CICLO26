import { BrowserRouter, Navigate, Route, Routes } from 'react-router-dom';
import Login from './pages/Login';
import Workspace from './pages/Workspace';
export default function App(){return <BrowserRouter><Routes><Route path="/login" element={<Login/>}/><Route path="/*" element={<Gate/>}/></Routes></BrowserRouter>}
function Gate(){return sessionStorage.getItem('mc_token')?<Workspace/>:<Navigate to="/login" replace/>}
