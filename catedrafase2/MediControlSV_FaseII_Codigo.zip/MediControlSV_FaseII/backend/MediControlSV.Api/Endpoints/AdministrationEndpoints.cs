using System.Security.Claims;
using MediControlSV.Api.Data;
using MediControlSV.Api.Models;
using MediControlSV.Api.Infrastructure;
using Microsoft.EntityFrameworkCore;
namespace MediControlSV.Api.Endpoints;
public static class AdministrationEndpoints {
 public sealed record CreateUser(string Nombre,string Correo,string Password,string Rol);
 public sealed record CreateDoctor(string Nombre,string Especialidad,string Jvpm,int UsuarioId);
 public sealed record CreateService(string Nombre,decimal Precio);
 public static void MapAdministration(this RouteGroupBuilder api) {
  api.MapGet("/usuarios",async(AppDbContext db)=>await db.Usuarios.AsNoTracking().OrderBy(x=>x.Nombre).Select(x=>new{x.Id,x.Nombre,x.Correo,x.Rol,x.Activo}).ToListAsync()).RequireAuthorization(p=>p.RequireRole("Administrador"));
  api.MapPost("/usuarios",async(CreateUser v,AppDbContext db,ClaimsPrincipal user)=>{
   if(string.IsNullOrWhiteSpace(v.Nombre)||v.Nombre.Length>160||!Helpers.Email(v.Correo)||!Helpers.StrongPassword(v.Password)||!new[]{"Administrador","Recepcionista","Medico","Paciente"}.Contains(v.Rol))return Helpers.Bad("Nombre, correo, contraseña fuerte y rol válido son obligatorios.");
   var mail=v.Correo.Trim().ToLowerInvariant();if(await db.Usuarios.AnyAsync(x=>x.Correo==mail))return Results.Conflict(new{error="Correo ya registrado."});
   var u=new Usuario{Nombre=v.Nombre.Trim(),Correo=mail,PasswordHash=BCrypt.Net.BCrypt.HashPassword(v.Password,workFactor:12),Rol=v.Rol};db.Usuarios.Add(u);await db.SaveChangesAsync();db.Auditorias.Add(new Auditoria{UsuarioId=Helpers.UserId(user),Accion="CREAR",Entidad="Usuario",EntidadId=u.Id});await db.SaveChangesAsync();return Results.Created($"/api/usuarios/{u.Id}",new{u.Id});
  }).RequireAuthorization(p=>p.RequireRole("Administrador"));
  api.MapPost("/medicos",async(CreateDoctor v,AppDbContext db,ClaimsPrincipal user)=>{
   if(string.IsNullOrWhiteSpace(v.Nombre)||v.Nombre.Length>160||string.IsNullOrWhiteSpace(v.Jvpm)||v.Jvpm.Length>50||string.IsNullOrWhiteSpace(v.Especialidad)||v.Especialidad.Length>100)return Helpers.Bad("Datos del médico inválidos.");
   if(!await db.Usuarios.AnyAsync(x=>x.Id==v.UsuarioId&&x.Rol=="Medico"&&x.Activo))return Helpers.Bad("El médico necesita una cuenta activa de rol Medico.");
   if(await db.Medicos.AnyAsync(x=>x.Jvpm==v.Jvpm||x.UsuarioId==v.UsuarioId))return Results.Conflict(new{error="JVPM o cuenta ya vinculados."});
   var m=new Medico{Nombre=v.Nombre.Trim(),Especialidad=v.Especialidad.Trim(),Jvpm=v.Jvpm.Trim(),UsuarioId=v.UsuarioId};db.Medicos.Add(m);await db.SaveChangesAsync();db.Auditorias.Add(new Auditoria{UsuarioId=Helpers.UserId(user),Entidad="Medico",EntidadId=m.Id,Accion="CREAR"});await db.SaveChangesAsync();return Results.Created($"/api/medicos/{m.Id}",new{m.Id});
  }).RequireAuthorization(p=>p.RequireRole("Administrador"));
  api.MapPost("/servicios",async(CreateService v,AppDbContext db,ClaimsPrincipal user)=>{
   if(string.IsNullOrWhiteSpace(v.Nombre)||v.Nombre.Length>140||v.Precio<0||v.Precio>100000)return Helpers.Bad("Servicio o precio inválidos.");var s=new Servicio{Nombre=v.Nombre.Trim(),Precio=v.Precio};db.Servicios.Add(s);await db.SaveChangesAsync();db.Auditorias.Add(new Auditoria{UsuarioId=Helpers.UserId(user),Accion="CREAR",Entidad="Servicio",EntidadId=s.Id});await db.SaveChangesAsync();return Results.Created($"/api/servicios/{s.Id}",new{s.Id});
  }).RequireAuthorization(p=>p.RequireRole("Administrador"));
  api.MapPost("/pacientes/{id:int}/vincular/{usuarioId:int}",async(int id,int usuarioId,AppDbContext db)=>{
   var p=await db.Pacientes.FindAsync(id);if(p==null)return Results.NotFound();if(!await db.Usuarios.AnyAsync(x=>x.Id==usuarioId&&x.Rol=="Paciente"&&x.Activo))return Helpers.Bad("Cuenta de paciente inexistente.");if(await db.Pacientes.AnyAsync(x=>x.UsuarioId==usuarioId&&x.Id!=id))return Results.Conflict(new{error="La cuenta ya pertenece a otro paciente."});p.UsuarioId=usuarioId;await db.SaveChangesAsync();return Results.NoContent();
  }).RequireAuthorization(p=>p.RequireRole("Administrador"));
 }
}
