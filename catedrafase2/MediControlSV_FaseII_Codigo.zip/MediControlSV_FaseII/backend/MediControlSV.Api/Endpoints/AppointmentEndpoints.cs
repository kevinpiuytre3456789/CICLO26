using System.Data;
using System.Security.Claims;
using MediControlSV.Api.Data;
using MediControlSV.Api.Infrastructure;
using MediControlSV.Api.Models;
using Microsoft.EntityFrameworkCore;
namespace MediControlSV.Api.Endpoints;
public static class AppointmentEndpoints {
 public sealed record AppointmentInput(int PacienteId,int MedicoId,int ServicioId,DateTime Inicio,DateTime Fin,string? Motivo);
 public static void MapAppointments(this RouteGroupBuilder api){
  var g=api.MapGroup("/citas");
  g.MapGet("/",async(AppDbContext db,ClaimsPrincipal user,DateTime? desde,DateTime? hasta)=>{
   var role=Helpers.Role(user);var uid=Helpers.UserId(user);var q=db.Citas.AsNoTracking().AsQueryable();
   if(role=="Paciente")q=q.Where(x=>x.Paciente!.UsuarioId==uid);else if(role=="Medico")q=q.Where(x=>x.Medico!.UsuarioId==uid);
   if(desde.HasValue)q=q.Where(x=>x.Inicio>=desde.Value);if(hasta.HasValue)q=q.Where(x=>x.Inicio<hasta.Value);
   return Results.Ok(await q.OrderByDescending(x=>x.Inicio).Take(200).Select(x=>new{x.Id,x.PacienteId,Paciente=x.Paciente!.Nombre,x.MedicoId,Medico=x.Medico!.Nombre,x.ServicioId,Servicio=x.Servicio!.Nombre,x.Inicio,x.Fin,x.Estado,x.Motivo}).ToListAsync());
  });
  g.MapPost("/",async(AppointmentInput v,AppDbContext db,ClaimsPrincipal user)=>{
   if(v.PacienteId<=0||v.MedicoId<=0||v.ServicioId<=0||v.Fin<=v.Inicio||v.Fin-v.Inicio>TimeSpan.FromHours(4)||v.Inicio<DateTime.Now||v.Inicio>DateTime.Now.AddYears(2)|| (v.Motivo??"").Length>500)return Helpers.Bad("Datos o rango de cita inválidos.");
   var uid=Helpers.UserId(user);if(Helpers.Role(user)=="Paciente"&&!await db.Pacientes.AnyAsync(x=>x.Id==v.PacienteId&&x.UsuarioId==uid))return Results.Forbid();
   if(!await db.Pacientes.AnyAsync(x=>x.Id==v.PacienteId&&x.Activo)||!await db.Medicos.AnyAsync(x=>x.Id==v.MedicoId&&x.Activo)||!await db.Servicios.AnyAsync(x=>x.Id==v.ServicioId&&x.Activo))return Helpers.Bad("Paciente, médico o servicio inexistente/inactivo.");
   await using var tx=await db.Database.BeginTransactionAsync(IsolationLevel.Serializable);
   if(await db.Citas.AnyAsync(x=>x.MedicoId==v.MedicoId&&x.Estado!="Cancelada"&&x.Inicio<v.Fin&&v.Inicio<x.Fin))return Results.Conflict(new{error="El médico ya tiene una cita en ese horario."});
   if(await db.BloqueosAgenda.AnyAsync(x=>x.MedicoId==v.MedicoId&&x.Inicio<v.Fin&&v.Inicio<x.Fin))return Results.Conflict(new{error="Horario bloqueado."});
   var c=new Cita{PacienteId=v.PacienteId,MedicoId=v.MedicoId,ServicioId=v.ServicioId,Inicio=v.Inicio,Fin=v.Fin,Motivo=v.Motivo?.Trim()??""};db.Citas.Add(c);await db.SaveChangesAsync();db.HistorialCitas.Add(new HistorialCita{CitaId=c.Id,UsuarioId=uid,EstadoNuevo="Confirmada"});db.Auditorias.Add(new Auditoria{UsuarioId=uid,Entidad="Cita",EntidadId=c.Id,Accion="CREAR"});await db.SaveChangesAsync();await tx.CommitAsync();return Results.Created($"/api/citas/{c.Id}",new{c.Id});
  }).RequireAuthorization(p=>p.RequireRole("Administrador","Recepcionista","Paciente"));
  g.MapPatch("/{id:int}/estado",async(int id,string estado,AppDbContext db,ClaimsPrincipal user)=>{
   var c=await db.Citas.FindAsync(id);if(c==null)return Results.NotFound();var role=Helpers.Role(user);if(role=="Paciente"&&(!await db.Pacientes.AnyAsync(x=>x.Id==c.PacienteId&&x.UsuarioId==Helpers.UserId(user))||estado!="Cancelada"))return Results.Forbid();if(role=="Medico"&&(!await db.Medicos.AnyAsync(x=>x.Id==c.MedicoId&&x.UsuarioId==Helpers.UserId(user))||estado is not ("En consulta" or "Finalizada")))return Results.Forbid();
   string[] allowed=["Confirmada","En espera","En consulta","Finalizada","Cancelada","No asistió"];if(!allowed.Contains(estado))return Helpers.Bad("Estado inválido.");if(c.Estado is "Finalizada" or "Cancelada")return Results.Conflict(new{error="La cita ya está cerrada."});var old=c.Estado;c.Estado=estado;db.HistorialCitas.Add(new HistorialCita{CitaId=id,UsuarioId=Helpers.UserId(user),EstadoAnterior=old,EstadoNuevo=estado});await db.SaveChangesAsync();return Results.NoContent();
  });
 }
}
