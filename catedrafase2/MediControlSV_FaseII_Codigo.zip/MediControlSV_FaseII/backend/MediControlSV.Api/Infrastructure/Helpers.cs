using System.Security.Claims;
using System.Text.RegularExpressions;
namespace MediControlSV.Api.Infrastructure;
public static class Helpers {
 public static bool StrongPassword(string value)=>value.Length>=12 && value.Length<=128 && value.Any(char.IsUpper)&&value.Any(char.IsLower)&&value.Any(char.IsDigit)&&value.Any(c=>!char.IsLetterOrDigit(c));
 public static bool Email(string value)=>value.Length<=200 && System.Net.Mail.MailAddress.TryCreate(value,out var x)&&x.Address==value;
 public static int? UserId(ClaimsPrincipal user)=>int.TryParse(user.FindFirstValue(ClaimTypes.NameIdentifier),out var x)?x:null;
 public static string? Role(ClaimsPrincipal user)=>user.FindFirstValue(ClaimTypes.Role);
 public static IResult Bad(string message)=>Results.BadRequest(new {error=message});
}
