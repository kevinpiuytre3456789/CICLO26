using System.Text;
using System.Security.Claims;
using MediControlSV.Api.Data;
using MediControlSV.Api.Endpoints;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using System.Threading.RateLimiting;

var builder = WebApplication.CreateBuilder(args);
var jwtKey = builder.Configuration["Jwt:Key"];
if (string.IsNullOrWhiteSpace(jwtKey) || Encoding.UTF8.GetByteCount(jwtKey) < 32)
    throw new InvalidOperationException("Configure Jwt:Key con un secreto aleatorio de al menos 32 bytes, fuera del repositorio (user-secrets o variables de entorno).");
builder.Services.AddDbContext<AppDbContext>(opt => opt.UseSqlServer(builder.Configuration.GetConnectionString("Default")));
builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme).AddJwtBearer(opt => {
    opt.TokenValidationParameters = new TokenValidationParameters {
        ValidateIssuer=true, ValidateAudience=true, ValidateIssuerSigningKey=true, ValidateLifetime=true,
        ValidIssuer=builder.Configuration["Jwt:Issuer"], ValidAudience=builder.Configuration["Jwt:Audience"],
        IssuerSigningKey=new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwtKey)),
        ClockSkew=TimeSpan.FromSeconds(30)
    };
});
builder.Services.AddAuthorization(o => o.AddPolicy("Administracion", p => p.RequireRole("Administrador","Recepcionista")));
builder.Services.AddCors(o => o.AddPolicy("Frontend", p => p.WithOrigins("http://localhost:5173", "http://127.0.0.1:5173").AllowAnyHeader().AllowAnyMethod()));
builder.Services.AddRateLimiter(options => {
    options.RejectionStatusCode=429;
    options.AddPolicy("login", context => RateLimitPartition.GetFixedWindowLimiter(context.Connection.RemoteIpAddress?.ToString()??"unknown", _=>new FixedWindowRateLimiterOptions{PermitLimit=10,Window=TimeSpan.FromMinutes(1),QueueLimit=0}));
});
var app=builder.Build();
if (!app.Environment.IsDevelopment()) app.UseHsts();
app.UseHttpsRedirection();
app.UseCors("Frontend");
app.UseRateLimiter();
app.UseAuthentication();app.UseAuthorization();
app.MapGet("/api/health", async (AppDbContext db) => await db.Database.CanConnectAsync() ? Results.Ok(new { estado="activo", baseDatos="conectada" }) : Results.Problem("Sin conexión a SQL Server", statusCode:503));
app.MapAuth();
var secured=app.MapGroup("/api").RequireAuthorization();
secured.MapPatients();
secured.MapAppointments();
secured.MapClinical();
secured.MapAdministration();
secured.MapClinicalRead();
secured.MapGet("/medicos",async(AppDbContext db)=>await db.Medicos.AsNoTracking().Where(x=>x.Activo).Select(x=>new{x.Id,x.Nombre,x.Especialidad,x.Jvpm}).ToListAsync());
secured.MapGet("/servicios",async(AppDbContext db)=>await db.Servicios.AsNoTracking().Where(x=>x.Activo).Select(x=>new{x.Id,x.Nombre,x.Precio}).ToListAsync());
secured.MapGet("/reportes/resumen",async(AppDbContext db)=>Results.Ok(new{pacientes=await db.Pacientes.CountAsync(),citas=await db.Citas.CountAsync(),consultas=await db.Consultas.CountAsync(),pagos=await db.Pagos.Where(x=>x.Estado=="Pagado").SumAsync(x=>(decimal?)x.Monto)??0m})).RequireAuthorization("Administracion");
using(var scope=app.Services.CreateScope()) await DbInitializer.Initialize(scope.ServiceProvider.GetRequiredService<AppDbContext>(),app.Configuration,app.Environment);
app.Run();
