# MediControl SV — Fase II, base reforzada

**Proyecto académico / ambiente de desarrollo. No apto para operar con información médica real sin evaluación profesional de seguridad, normativa, respaldos y pruebas.**

## Incluye
- Frontend React + TypeScript + Vite importado de Figma Make.
- Sección **Operaciones reales (SQL)**: crear pacientes, agendar citas, listar pacientes y citas desde una API.
- Backend ASP.NET Core 10 Minimal API, EF Core SQL Server, entidades del modelo relacional de Fase I.
- Inicio de sesión BCrypt y JWT de 30 minutos, autorización por roles en backend, controles de datos, limitador de intentos de acceso, historial de citas y auditoría de altas.
- API para consultas, recetas, órdenes de estudios, seguimientos, pagos y lectura de auditoría (las pantallas de Figma no están todavía conectadas a todos estos endpoints).

## Requisitos
1. .NET SDK 10, SQL Server local, Node.js 22+, Visual Studio 2022/2026 compatible o terminal.
2. Base de datos SQL Server disponible con autenticación Windows o actualizar `ConnectionStrings:Default` mediante user-secrets.
3. Para desarrollo, configurar secretos fuera de Git:

```powershell
cd backend/MediControlSV.Api
dotnet user-secrets init
dotnet user-secrets set "Jwt:Key" "CAMBIAR_ESTO_POR_UN_VALOR_ALEATORIO_CRIPTOGRAFICO_DE_32_BYTES_O_MAS"
dotnet user-secrets set "Seed:AdminEmail" "admin@ejemplo.local"
dotnet user-secrets set "Seed:AdminPassword" "CambiarEstaClave!2026"
dotnet user-secrets set "Database:InitializeDevelopment" "true"
dotnet run --urls "http://localhost:5080"
```

**No copies claves de ejemplo al publicar.** `EnsureCreated()` crea esquema inicial solo en desarrollo; para el ciclo real se deben incorporar migraciones EF Core y desplegarlas de forma controlada. En un SQL Server existente donde ya haya tablas, usar una base de datos nueva para evitar incompatibilidades.

En otra consola:
```powershell
cd frontend
npm install
npm run dev
```

Abrir `http://localhost:5173`, iniciar sesión y seleccionar **Operaciones reales (SQL)** del menú. Para que las citas funcionen, registrar al menos un médico válido en SQL Server y configurarle un usuario Médico.

## Ejemplo de alta de médico de DESARROLLO
El módulo de gestión de médicos todavía no tiene interfaz operativa. Tras crear la base, en SSMS:
```sql
INSERT INTO Medicos (Nombre, Especialidad, Jvpm, Activo)
VALUES (N'Dra. Prueba Docente', N'Medicina General', N'JVPM-DEMO-01', 1);
```

## Seguridad y límites importantes
- API requiere `Jwt__Key` seguro desde ambiente/user-secrets; NO se entrega clave JWT por defecto.
- JWT se guarda en `sessionStorage` para el prototipo. En producción se necesita una estrategia de sesiones más robusta, control de revocación, mitigación XSS, renovación segura y protección contra ataques web.
- `TrustServerCertificate=True` solo para SQL Server local; en producción configurar TLS válido.
- No se entregan migraciones probadas, test de integración ni endurecimiento de infraestructura.
- Se requieren autorizaciones más finas para permitir a un médico consultar únicamente expedientes asociados; la política de historias clínicas debe revisarse como parte del diseño de acceso.
- Falta desarrollar carga privada de archivos y validación antivirus, recuperación de contraseña, correos, notificaciones reales, transiciones de agenda completas, catálogo administrativo, fichas clínicas detalladas, exportables y todos los formularios.
- Las páginas originales de Figma se conservan como **maquetas con datos simulados**, salvo `Operaciones reales (SQL)` y login.
- No guardar datos reales de pacientes para pruebas: usar información inventada.

## Rutas principales API
`POST /api/auth/login`, `GET /api/auth/me`, `GET|POST|PUT /api/pacientes`, `GET|POST /api/citas`, `PATCH /api/citas/{id}/estado`, `GET|POST /api/consultas`, `POST|GET /api/recetas`, `POST|GET /api/pagos`, `POST /api/estudios`, `POST /api/seguimientos`, `GET /api/auditoria`, `GET /api/reportes/resumen`.

## Verificación
Este entorno de generación no cuenta con `dotnet`, por lo que **no se ha compilado ni ejecutado el backend**. La implementación requiere compilación local y pruebas end-to-end antes de considerarla terminada.
