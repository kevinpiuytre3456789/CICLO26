
  # Hotel Booking Admin Dashboard (Community)

  This is a code bundle for Hotel Booking Admin Dashboard (Community). The original project is available at https://www.figma.com/design/lUPRRcV9Ues77I5UB0NBST/Hotel-Booking-Admin-Dashboard--Community-.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  