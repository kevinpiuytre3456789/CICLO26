import { Search, Mail, Phone, MapPin, Calendar, User, CreditCard } from 'lucide-react';
import { useState } from 'react';

const guests = [
  {
    id: 1,
    name: 'John Smith',
    email: 'john.smith@email.com',
    phone: '+1 (555) 123-4567',
    room: '102',
    checkIn: '2024-12-18',
    checkOut: '2024-12-22',
    status: 'checked-in',
    country: 'USA',
    totalSpent: '$1,240',
    visits: 3,
  },
  {
    id: 2,
    name: 'Emma Wilson',
    email: 'emma.wilson@email.com',
    phone: '+44 7700 900123',
    room: '103',
    checkIn: '2024-12-19',
    checkOut: '2024-12-24',
    status: 'checked-in',
    country: 'UK',
    totalSpent: '$2,180',
    visits: 5,
  },
  {
    id: 3,
    name: 'Michael Brown',
    email: 'michael.b@email.com',
    phone: '+1 (555) 234-5678',
    room: '201',
    checkIn: '2024-12-17',
    checkOut: '2024-12-21',
    status: 'checked-in',
    country: 'Canada',
    totalSpent: '$890',
    visits: 2,
  },
  {
    id: 4,
    name: 'Sarah Davis',
    email: 'sarah.davis@email.com',
    phone: '+61 412 345 678',
    room: '301',
    checkIn: '2024-12-20',
    checkOut: '2024-12-25',
    status: 'checked-in',
    country: 'Australia',
    totalSpent: '$3,450',
    visits: 8,
  },
  {
    id: 5,
    name: 'James Taylor',
    email: 'james.t@email.com',
    phone: '+1 (555) 345-6789',
    room: '303',
    checkIn: '2024-12-19',
    checkOut: '2024-12-23',
    status: 'checked-in',
    country: 'USA',
    totalSpent: '$1,670',
    visits: 4,
  },
  {
    id: 6,
    name: 'Lisa Anderson',
    email: 'lisa.anderson@email.com',
    phone: '+49 151 12345678',
    room: '401',
    checkIn: '2024-12-21',
    checkOut: '2024-12-26',
    status: 'upcoming',
    country: 'Germany',
    totalSpent: '$2,890',
    visits: 6,
  },
];

export function GuestList() {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedGuest, setSelectedGuest] = useState(guests[0]);

  const filteredGuests = guests.filter(guest =>
    guest.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    guest.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
    guest.room.includes(searchTerm)
  );

  return (
    <div className="space-y-6">
      {/* Search Bar */}
      <div className="bg-white p-4 rounded-xl shadow-sm border border-gray-200">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
          <input
            type="text"
            placeholder="Search guests by name, email, or room number..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Guest List */}
        <div className="lg:col-span-1 bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
          <div className="p-4 border-b border-gray-200">
            <h3 className="text-lg">All Guests ({filteredGuests.length})</h3>
          </div>
          <div className="overflow-y-auto max-h-[600px]">
            {filteredGuests.map((guest) => (
              <div
                key={guest.id}
                onClick={() => setSelectedGuest(guest)}
                className={`p-4 border-b border-gray-100 cursor-pointer transition-colors ${
                  selectedGuest.id === guest.id ? 'bg-blue-50 border-l-4 border-l-blue-600' : 'hover:bg-gray-50'
                }`}
              >
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <h4 className="font-medium">{guest.name}</h4>
                    <p className="text-sm text-gray-600 mt-1">Room {guest.room}</p>
                    <span className={`inline-block mt-2 px-2 py-1 rounded-full text-xs ${
                      guest.status === 'checked-in' 
                        ? 'bg-green-100 text-green-700' 
                        : 'bg-blue-100 text-blue-700'
                    }`}>
                      {guest.status === 'checked-in' ? 'Checked In' : 'Upcoming'}
                    </span>
                  </div>
                  <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                    <User className="w-5 h-5 text-blue-600" />
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Guest Profile */}
        <div className="lg:col-span-2 bg-white rounded-xl shadow-sm border border-gray-200">
          <div className="p-6 border-b border-gray-200">
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-4">
                <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center">
                  <User className="w-8 h-8 text-blue-600" />
                </div>
                <div>
                  <h3 className="text-2xl">{selectedGuest.name}</h3>
                  <p className="text-gray-600">Guest ID: #{selectedGuest.id.toString().padStart(4, '0')}</p>
                </div>
              </div>
              <span className={`px-3 py-1.5 rounded-full text-sm ${
                selectedGuest.status === 'checked-in' 
                  ? 'bg-green-100 text-green-700' 
                  : 'bg-blue-100 text-blue-700'
              }`}>
                {selectedGuest.status === 'checked-in' ? 'Checked In' : 'Upcoming'}
              </span>
            </div>
          </div>

          <div className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
              {/* Contact Information */}
              <div className="space-y-4">
                <h4 className="font-medium text-gray-900">Contact Information</h4>
                <div className="space-y-3">
                  <div className="flex items-center gap-3 text-gray-700">
                    <Mail className="w-5 h-5 text-gray-400" />
                    <span className="text-sm">{selectedGuest.email}</span>
                  </div>
                  <div className="flex items-center gap-3 text-gray-700">
                    <Phone className="w-5 h-5 text-gray-400" />
                    <span className="text-sm">{selectedGuest.phone}</span>
                  </div>
                  <div className="flex items-center gap-3 text-gray-700">
                    <MapPin className="w-5 h-5 text-gray-400" />
                    <span className="text-sm">{selectedGuest.country}</span>
                  </div>
                </div>
              </div>

              {/* Booking Information */}
              <div className="space-y-4">
                <h4 className="font-medium text-gray-900">Current Booking</h4>
                <div className="space-y-3">
                  <div className="flex items-center gap-3 text-gray-700">
                    <Calendar className="w-5 h-5 text-gray-400" />
                    <div className="text-sm">
                      <p className="text-gray-600">Check-in</p>
                      <p>{selectedGuest.checkIn}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3 text-gray-700">
                    <Calendar className="w-5 h-5 text-gray-400" />
                    <div className="text-sm">
                      <p className="text-gray-600">Check-out</p>
                      <p>{selectedGuest.checkOut}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3 text-gray-700">
                    <MapPin className="w-5 h-5 text-gray-400" />
                    <span className="text-sm">Room {selectedGuest.room}</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Statistics */}
            <div className="grid grid-cols-2 gap-4 mb-6">
              <div className="bg-blue-50 p-4 rounded-lg">
                <div className="flex items-center gap-2 text-blue-600 mb-2">
                  <CreditCard className="w-5 h-5" />
                  <p className="text-sm">Total Spent</p>
                </div>
                <p className="text-2xl text-blue-900">{selectedGuest.totalSpent}</p>
              </div>
              <div className="bg-purple-50 p-4 rounded-lg">
                <div className="flex items-center gap-2 text-purple-600 mb-2">
                  <Calendar className="w-5 h-5" />
                  <p className="text-sm">Total Visits</p>
                </div>
                <p className="text-2xl text-purple-900">{selectedGuest.visits}</p>
              </div>
            </div>

            {/* Booking History */}
            <div>
              <h4 className="font-medium text-gray-900 mb-3">Booking History</h4>
              <div className="space-y-2">
                {[
                  { date: '2024-12-18 - 2024-12-22', room: '102', amount: '$480' },
                  { date: '2024-08-15 - 2024-08-20', room: '304', amount: '$600' },
                  { date: '2024-03-10 - 2024-03-14', room: '201', amount: '$560' },
                ].map((booking, index) => (
                  <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div>
                      <p className="text-sm">{booking.date}</p>
                      <p className="text-xs text-gray-600">Room {booking.room}</p>
                    </div>
                    <p className="font-medium">{booking.amount}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
