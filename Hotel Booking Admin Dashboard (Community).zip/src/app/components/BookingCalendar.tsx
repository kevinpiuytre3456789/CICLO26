import { ChevronLeft, ChevronRight, Calendar as CalendarIcon } from 'lucide-react';
import { useState } from 'react';

const bookings = [
  { id: 1, guest: 'John Smith', room: '102', start: 18, end: 22, color: 'bg-blue-500' },
  { id: 2, guest: 'Emma Wilson', room: '103', start: 19, end: 24, color: 'bg-green-500' },
  { id: 3, guest: 'Michael Brown', room: '201', start: 17, end: 21, color: 'bg-purple-500' },
  { id: 4, guest: 'Sarah Davis', room: '301', start: 20, end: 25, color: 'bg-orange-500' },
  { id: 5, guest: 'James Taylor', room: '303', start: 19, end: 23, color: 'bg-pink-500' },
  { id: 6, guest: 'Lisa Anderson', room: '401', start: 21, end: 26, color: 'bg-teal-500' },
];

const rooms = ['101', '102', '103', '104', '201', '202', '203', '204', '301', '302', '303', '304', '401', '402', '403', '404'];

export function BookingCalendar() {
  const [currentMonth] = useState('December 2024');
  const days = Array.from({ length: 31 }, (_, i) => i + 1);

  const getBookingForRoom = (room: string, day: number) => {
    return bookings.find(b => b.room === room && day >= b.start && day <= b.end);
  };

  return (
    <div className="space-y-6">
      {/* Calendar Header */}
      <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
        <div className="flex items-center justify-between">
          <h2 className="text-2xl flex items-center gap-2">
            <CalendarIcon className="w-6 h-6" />
            Booking Calendar
          </h2>
          <div className="flex items-center gap-4">
            <button className="p-2 hover:bg-gray-100 rounded-lg transition-colors">
              <ChevronLeft className="w-5 h-5" />
            </button>
            <span className="font-medium min-w-[150px] text-center">{currentMonth}</span>
            <button className="p-2 hover:bg-gray-100 rounded-lg transition-colors">
              <ChevronRight className="w-5 h-5" />
            </button>
          </div>
          <div className="flex gap-2">
            <button className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
              Add Booking
            </button>
          </div>
        </div>
      </div>

      {/* Legend */}
      <div className="bg-white p-4 rounded-xl shadow-sm border border-gray-200">
        <div className="flex items-center gap-6">
          <span className="text-sm text-gray-600">Status:</span>
          {[
            { label: 'Available', color: 'bg-gray-100' },
            { label: 'Booking 1', color: 'bg-blue-500' },
            { label: 'Booking 2', color: 'bg-green-500' },
            { label: 'Booking 3', color: 'bg-purple-500' },
            { label: 'Booking 4', color: 'bg-orange-500' },
          ].map((item, index) => (
            <div key={index} className="flex items-center gap-2">
              <div className={`w-4 h-4 rounded ${item.color}`}></div>
              <span className="text-sm text-gray-700">{item.label}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Calendar Grid */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-x-auto">
        <table className="w-full min-w-[1200px]">
          <thead className="bg-gray-50 sticky top-0">
            <tr>
              <th className="px-4 py-3 text-left text-sm text-gray-600 sticky left-0 bg-gray-50 z-10 border-r border-gray-200">
                Room
              </th>
              {days.map(day => (
                <th key={day} className="px-2 py-3 text-center text-sm text-gray-600 min-w-[40px]">
                  {day}
                </th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-200">
            {rooms.map(room => (
              <tr key={room} className="hover:bg-gray-50">
                <td className="px-4 py-3 font-medium sticky left-0 bg-white z-10 border-r border-gray-200">
                  {room}
                </td>
                {days.map(day => {
                  const booking = getBookingForRoom(room, day);
                  const isStart = booking && day === booking.start;
                  const isEnd = booking && day === booking.end;
                  
                  return (
                    <td key={day} className="px-0 py-1">
                      {booking ? (
                        <div className={`h-8 ${booking.color} ${isStart ? 'rounded-l-md' : ''} ${isEnd ? 'rounded-r-md' : ''} relative group`}>
                          {isStart && (
                            <div className="absolute left-1 top-1/2 transform -translate-y-1/2 text-white text-xs truncate max-w-[100px] opacity-0 group-hover:opacity-100 transition-opacity">
                              {booking.guest}
                            </div>
                          )}
                        </div>
                      ) : (
                        <div className="h-8 bg-gray-100 hover:bg-gray-200 cursor-pointer transition-colors"></div>
                      )}
                    </td>
                  );
                })}
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Upcoming Bookings */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200">
        <div className="p-6 border-b border-gray-200">
          <h3 className="text-lg">Upcoming Bookings</h3>
        </div>
        <div className="p-6">
          <div className="space-y-3">
            {bookings.filter(b => b.start >= 20).map(booking => (
              <div key={booking.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
                <div className="flex items-center gap-4">
                  <div className={`w-3 h-3 rounded-full ${booking.color}`}></div>
                  <div>
                    <p className="font-medium">{booking.guest}</p>
                    <p className="text-sm text-gray-600">Room {booking.room}</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-sm">Dec {booking.start} - Dec {booking.end}</p>
                  <p className="text-xs text-gray-600">{booking.end - booking.start} nights</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
