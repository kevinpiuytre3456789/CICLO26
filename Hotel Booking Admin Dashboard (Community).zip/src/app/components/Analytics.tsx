import { 
  BarChart, 
  Bar, 
  LineChart, 
  Line, 
  PieChart, 
  Pie, 
  Cell,
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer 
} from 'recharts';
import { TrendingUp, Users, DollarSign, Calendar } from 'lucide-react';

const monthlyRevenue = [
  { month: 'Jan', revenue: 45000, bookings: 120, occupancy: 62 },
  { month: 'Feb', revenue: 52000, bookings: 145, occupancy: 68 },
  { month: 'Mar', revenue: 48000, bookings: 132, occupancy: 65 },
  { month: 'Apr', revenue: 61000, bookings: 168, occupancy: 72 },
  { month: 'May', revenue: 72000, bookings: 195, occupancy: 78 },
  { month: 'Jun', revenue: 68000, bookings: 182, occupancy: 75 },
  { month: 'Jul', revenue: 85000, bookings: 220, occupancy: 85 },
  { month: 'Aug', revenue: 82000, bookings: 215, occupancy: 83 },
  { month: 'Sep', revenue: 71000, bookings: 190, occupancy: 76 },
  { month: 'Oct', revenue: 64000, bookings: 175, occupancy: 70 },
  { month: 'Nov', revenue: 58000, bookings: 160, occupancy: 67 },
  { month: 'Dec', revenue: 68000, bookings: 182, occupancy: 73 },
];

const roomTypeRevenue = [
  { type: 'Standard', revenue: 185000, bookings: 850, color: '#3b82f6' },
  { type: 'Deluxe', revenue: 245000, bookings: 620, color: '#10b981' },
  { type: 'Suite', revenue: 315000, bookings: 420, color: '#f59e0b' },
  { type: 'Presidential', revenue: 185000, bookings: 95, color: '#8b5cf6' },
];

const guestDemographics = [
  { country: 'USA', guests: 450, color: '#3b82f6' },
  { country: 'UK', guests: 320, color: '#10b981' },
  { country: 'Canada', guests: 280, color: '#f59e0b' },
  { country: 'Australia', guests: 220, color: '#8b5cf6' },
  { country: 'Germany', guests: 180, color: '#ec4899' },
  { country: 'Others', guests: 350, color: '#6b7280' },
];

const dailyOccupancy = [
  { day: 'Mon', rate: 65 },
  { day: 'Tue', rate: 58 },
  { day: 'Wed', rate: 62 },
  { day: 'Thu', rate: 71 },
  { day: 'Fri', rate: 85 },
  { day: 'Sat', rate: 92 },
  { day: 'Sun', rate: 78 },
];

export function Analytics() {
  return (
    <div className="space-y-6">
      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-gradient-to-br from-blue-500 to-blue-600 p-6 rounded-xl shadow-lg text-white">
          <div className="flex items-center justify-between mb-4">
            <DollarSign className="w-8 h-8 opacity-80" />
            <TrendingUp className="w-5 h-5" />
          </div>
          <p className="text-sm opacity-90">Annual Revenue</p>
          <h3 className="text-3xl mt-2">$774K</h3>
          <p className="text-sm mt-2 opacity-80">+15.3% vs last year</p>
        </div>

        <div className="bg-gradient-to-br from-green-500 to-green-600 p-6 rounded-xl shadow-lg text-white">
          <div className="flex items-center justify-between mb-4">
            <Calendar className="w-8 h-8 opacity-80" />
            <TrendingUp className="w-5 h-5" />
          </div>
          <p className="text-sm opacity-90">Total Bookings</p>
          <h3 className="text-3xl mt-2">2,054</h3>
          <p className="text-sm mt-2 opacity-80">+12.8% vs last year</p>
        </div>

        <div className="bg-gradient-to-br from-purple-500 to-purple-600 p-6 rounded-xl shadow-lg text-white">
          <div className="flex items-center justify-between mb-4">
            <Users className="w-8 h-8 opacity-80" />
            <TrendingUp className="w-5 h-5" />
          </div>
          <p className="text-sm opacity-90">Total Guests</p>
          <h3 className="text-3xl mt-2">5,248</h3>
          <p className="text-sm mt-2 opacity-80">+18.5% vs last year</p>
        </div>

        <div className="bg-gradient-to-br from-orange-500 to-orange-600 p-6 rounded-xl shadow-lg text-white">
          <div className="flex items-center justify-between mb-4">
            <TrendingUp className="w-8 h-8 opacity-80" />
            <TrendingUp className="w-5 h-5" />
          </div>
          <p className="text-sm opacity-90">Avg Occupancy</p>
          <h3 className="text-3xl mt-2">72.4%</h3>
          <p className="text-sm mt-2 opacity-80">+5.2% vs last year</p>
        </div>
      </div>

      {/* Revenue and Bookings Chart */}
      <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
        <h3 className="text-lg mb-6">Monthly Revenue & Bookings Trend</h3>
        <ResponsiveContainer width="100%" height={350}>
          <LineChart data={monthlyRevenue}>
            <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
            <XAxis dataKey="month" stroke="#9ca3af" />
            <YAxis yAxisId="left" stroke="#9ca3af" />
            <YAxis yAxisId="right" orientation="right" stroke="#9ca3af" />
            <Tooltip 
              contentStyle={{ 
                backgroundColor: '#fff', 
                border: '1px solid #e5e7eb',
                borderRadius: '8px'
              }} 
            />
            <Legend />
            <Line 
              yAxisId="left"
              type="monotone" 
              dataKey="revenue" 
              stroke="#3b82f6" 
              strokeWidth={3}
              dot={{ r: 5 }}
              activeDot={{ r: 7 }}
              name="Revenue ($)"
            />
            <Line 
              yAxisId="right"
              type="monotone" 
              dataKey="bookings" 
              stroke="#10b981" 
              strokeWidth={3}
              dot={{ r: 5 }}
              activeDot={{ r: 7 }}
              name="Bookings"
            />
          </LineChart>
        </ResponsiveContainer>
      </div>

      {/* Room Type Performance & Guest Demographics */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Room Type Revenue */}
        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
          <h3 className="text-lg mb-6">Revenue by Room Type</h3>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={roomTypeRevenue}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
              <XAxis dataKey="type" stroke="#9ca3af" />
              <YAxis stroke="#9ca3af" />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: '#fff', 
                  border: '1px solid #e5e7eb',
                  borderRadius: '8px'
                }} 
              />
              <Bar dataKey="revenue" radius={[8, 8, 0, 0]}>
                {roomTypeRevenue.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Guest Demographics */}
        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
          <h3 className="text-lg mb-6">Guest Demographics</h3>
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie
                data={guestDemographics}
                cx="50%"
                cy="50%"
                labelLine={false}
                label={({ country, percent }) => `${country} ${(percent * 100).toFixed(0)}%`}
                outerRadius={100}
                dataKey="guests"
              >
                {guestDemographics.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Weekly Occupancy & Room Type Details */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Daily Occupancy */}
        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
          <h3 className="text-lg mb-6">Weekly Occupancy Rate</h3>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={dailyOccupancy}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
              <XAxis dataKey="day" stroke="#9ca3af" />
              <YAxis stroke="#9ca3af" unit="%" />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: '#fff', 
                  border: '1px solid #e5e7eb',
                  borderRadius: '8px'
                }} 
              />
              <Bar dataKey="rate" fill="#8b5cf6" radius={[8, 8, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Room Type Stats */}
        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
          <h3 className="text-lg mb-6">Room Type Performance</h3>
          <div className="space-y-4">
            {roomTypeRevenue.map((room, index) => (
              <div key={index} className="p-4 bg-gray-50 rounded-lg">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-3">
                    <div className="w-4 h-4 rounded" style={{ backgroundColor: room.color }}></div>
                    <span className="font-medium">{room.type}</span>
                  </div>
                  <span className="text-lg font-medium">${(room.revenue / 1000).toFixed(0)}K</span>
                </div>
                <div className="flex items-center justify-between text-sm text-gray-600">
                  <span>{room.bookings} bookings</span>
                  <span>${(room.revenue / room.bookings).toFixed(0)} avg/booking</span>
                </div>
                <div className="mt-2 w-full bg-gray-200 rounded-full h-2">
                  <div 
                    className="h-2 rounded-full" 
                    style={{ 
                      width: `${(room.bookings / 850) * 100}%`,
                      backgroundColor: room.color 
                    }}
                  ></div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
