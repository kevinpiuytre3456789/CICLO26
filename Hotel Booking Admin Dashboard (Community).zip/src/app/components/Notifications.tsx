import { Bell, MessageSquare, AlertCircle, CheckCircle, Info, Calendar, DollarSign } from 'lucide-react';
import { useState } from 'react';

const notifications = [
  {
    id: 1,
    type: 'booking',
    title: 'New Booking Received',
    message: 'Emma Wilson booked Room 512 for Dec 21-25',
    time: '5 minutes ago',
    read: false,
    icon: Calendar,
    color: 'blue',
  },
  {
    id: 2,
    type: 'payment',
    title: 'Payment Received',
    message: 'John Smith paid $480 for booking #12345',
    time: '15 minutes ago',
    read: false,
    icon: DollarSign,
    color: 'green',
  },
  {
    id: 3,
    type: 'alert',
    title: 'Maintenance Alert',
    message: 'Room 402 requires immediate attention - AC not working',
    time: '1 hour ago',
    read: false,
    icon: AlertCircle,
    color: 'orange',
  },
  {
    id: 4,
    type: 'message',
    title: 'Guest Message',
    message: 'Sarah Davis: "Can I get early check-in at 11 AM?"',
    time: '2 hours ago',
    read: true,
    icon: MessageSquare,
    color: 'purple',
  },
  {
    id: 5,
    type: 'info',
    title: 'Check-out Reminder',
    message: 'Michael Brown - Room 201 check-out today at 11 AM',
    time: '3 hours ago',
    read: true,
    icon: Info,
    color: 'blue',
  },
  {
    id: 6,
    type: 'success',
    title: 'Booking Confirmed',
    message: 'Lisa Anderson booking confirmed - Room 401',
    time: '5 hours ago',
    read: true,
    icon: CheckCircle,
    color: 'green',
  },
];

const messages = [
  {
    id: 1,
    guest: 'Sarah Davis',
    room: '301',
    message: 'Can I request early check-in at 11 AM tomorrow?',
    time: '2 hours ago',
    unread: true,
  },
  {
    id: 2,
    guest: 'John Smith',
    room: '102',
    message: 'Could you arrange airport pickup service?',
    time: '4 hours ago',
    unread: true,
  },
  {
    id: 3,
    guest: 'Emma Wilson',
    room: '103',
    message: 'Thank you for the room upgrade!',
    time: '1 day ago',
    unread: false,
  },
  {
    id: 4,
    guest: 'Michael Brown',
    room: '201',
    message: 'Is late checkout available? I have a 6 PM flight.',
    time: '1 day ago',
    unread: false,
  },
];

export function Notifications() {
  const [activeTab, setActiveTab] = useState<'notifications' | 'messages'>('notifications');
  const [notificationList, setNotificationList] = useState(notifications);

  const unreadCount = notificationList.filter(n => !n.read).length;
  const unreadMessages = messages.filter(m => m.unread).length;

  const markAsRead = (id: number) => {
    setNotificationList(notificationList.map(n => 
      n.id === id ? { ...n, read: true } : n
    ));
  };

  const markAllAsRead = () => {
    setNotificationList(notificationList.map(n => ({ ...n, read: true })));
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Bell className="w-6 h-6 text-blue-600" />
            <h2 className="text-2xl">Notifications & Messages</h2>
          </div>
          {activeTab === 'notifications' && unreadCount > 0 && (
            <button
              onClick={markAllAsRead}
              className="px-4 py-2 text-sm text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
            >
              Mark all as read
            </button>
          )}
        </div>
      </div>

      {/* Tabs */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200">
        <div className="flex border-b border-gray-200">
          <button
            onClick={() => setActiveTab('notifications')}
            className={`flex-1 px-6 py-4 flex items-center justify-center gap-2 transition-colors ${
              activeTab === 'notifications'
                ? 'border-b-2 border-blue-600 text-blue-600'
                : 'text-gray-600 hover:text-gray-900'
            }`}
          >
            <Bell className="w-5 h-5" />
            <span>Notifications</span>
            {unreadCount > 0 && (
              <span className="ml-2 px-2 py-0.5 bg-blue-600 text-white text-xs rounded-full">
                {unreadCount}
              </span>
            )}
          </button>
          <button
            onClick={() => setActiveTab('messages')}
            className={`flex-1 px-6 py-4 flex items-center justify-center gap-2 transition-colors ${
              activeTab === 'messages'
                ? 'border-b-2 border-blue-600 text-blue-600'
                : 'text-gray-600 hover:text-gray-900'
            }`}
          >
            <MessageSquare className="w-5 h-5" />
            <span>Messages</span>
            {unreadMessages > 0 && (
              <span className="ml-2 px-2 py-0.5 bg-blue-600 text-white text-xs rounded-full">
                {unreadMessages}
              </span>
            )}
          </button>
        </div>

        {/* Notifications Tab */}
        {activeTab === 'notifications' && (
          <div className="divide-y divide-gray-200">
            {notificationList.map((notification) => {
              const Icon = notification.icon;
              const colorClasses = {
                blue: 'bg-blue-100 text-blue-600',
                green: 'bg-green-100 text-green-600',
                orange: 'bg-orange-100 text-orange-600',
                purple: 'bg-purple-100 text-purple-600',
              }[notification.color];

              return (
                <div
                  key={notification.id}
                  onClick={() => markAsRead(notification.id)}
                  className={`p-6 hover:bg-gray-50 cursor-pointer transition-colors ${
                    !notification.read ? 'bg-blue-50' : ''
                  }`}
                >
                  <div className="flex gap-4">
                    <div className={`w-12 h-12 rounded-lg ${colorClasses} flex items-center justify-center flex-shrink-0`}>
                      <Icon className="w-6 h-6" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between mb-1">
                        <h4 className="font-medium">{notification.title}</h4>
                        <span className="text-xs text-gray-500 whitespace-nowrap ml-2">
                          {notification.time}
                        </span>
                      </div>
                      <p className="text-sm text-gray-600">{notification.message}</p>
                    </div>
                    {!notification.read && (
                      <div className="w-2 h-2 bg-blue-600 rounded-full flex-shrink-0 mt-2"></div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* Messages Tab */}
        {activeTab === 'messages' && (
          <div className="divide-y divide-gray-200">
            {messages.map((message) => (
              <div
                key={message.id}
                className={`p-6 hover:bg-gray-50 cursor-pointer transition-colors ${
                  message.unread ? 'bg-blue-50' : ''
                }`}
              >
                <div className="flex gap-4">
                  <div className="w-12 h-12 bg-purple-100 text-purple-600 rounded-full flex items-center justify-center flex-shrink-0">
                    <MessageSquare className="w-6 h-6" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between mb-1">
                      <div>
                        <h4 className="font-medium">{message.guest}</h4>
                        <p className="text-xs text-gray-500">Room {message.room}</p>
                      </div>
                      <span className="text-xs text-gray-500 whitespace-nowrap ml-2">
                        {message.time}
                      </span>
                    </div>
                    <p className="text-sm text-gray-600 mt-2">{message.message}</p>
                    <div className="flex gap-2 mt-3">
                      <button className="px-3 py-1.5 bg-blue-600 text-white text-sm rounded-lg hover:bg-blue-700 transition-colors">
                        Reply
                      </button>
                      <button className="px-3 py-1.5 bg-gray-100 text-gray-700 text-sm rounded-lg hover:bg-gray-200 transition-colors">
                        Mark as Read
                      </button>
                    </div>
                  </div>
                  {message.unread && (
                    <div className="w-2 h-2 bg-blue-600 rounded-full flex-shrink-0 mt-2"></div>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
