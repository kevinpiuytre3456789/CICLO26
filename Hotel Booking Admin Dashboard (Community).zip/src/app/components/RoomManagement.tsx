import { Bed, Users, Wrench, Check, DollarSign, Filter } from 'lucide-react';
import { useState } from 'react';

const rooms = [
  { id: '101', type: 'Standard', capacity: 2, status: 'available', price: 120, floor: 1 },
  { id: '102', type: 'Standard', capacity: 2, status: 'occupied', price: 120, floor: 1, guest: 'John Smith' },
  { id: '103', type: 'Deluxe', capacity: 3, status: 'occupied', price: 180, floor: 1, guest: 'Emma Wilson' },
  { id: '104', type: 'Standard', capacity: 2, status: 'available', price: 120, floor: 1 },
  { id: '201', type: 'Suite', capacity: 4, status: 'occupied', price: 350, floor: 2, guest: 'Michael Brown' },
  { id: '202', type: 'Deluxe', capacity: 3, status: 'available', price: 180, floor: 2 },
  { id: '203', type: 'Standard', capacity: 2, status: 'maintenance', price: 120, floor: 2 },
  { id: '204', type: 'Suite', capacity: 4, status: 'available', price: 350, floor: 2 },
  { id: '301', type: 'Standard', capacity: 2, status: 'occupied', price: 120, floor: 3, guest: 'Sarah Davis' },
  { id: '302', type: 'Deluxe', capacity: 3, status: 'available', price: 180, floor: 3 },
  { id: '303', type: 'Standard', capacity: 2, status: 'occupied', price: 120, floor: 3, guest: 'James Taylor' },
  { id: '304', type: 'Standard', capacity: 2, status: 'available', price: 120, floor: 3 },
  { id: '401', type: 'Suite', capacity: 4, status: 'occupied', price: 350, floor: 4, guest: 'Lisa Anderson' },
  { id: '402', type: 'Deluxe', capacity: 3, status: 'maintenance', price: 180, floor: 4 },
  { id: '403', type: 'Presidential', capacity: 6, status: 'available', price: 850, floor: 4 },
  { id: '404', type: 'Suite', capacity: 4, status: 'available', price: 350, floor: 4 },
];

export function RoomManagement() {
  const [filter, setFilter] = useState<string>('all');
  
  const filteredRooms = filter === 'all' 
    ? rooms 
    : rooms.filter(room => room.status === filter);

  const stats = {
    available: rooms.filter(r => r.status === 'available').length,
    occupied: rooms.filter(r => r.status === 'occupied').length,
    maintenance: rooms.filter(r => r.status === 'maintenance').length,
    total: rooms.length,
  };

  return (
    <div className="space-y-6">
      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Total Rooms</p>
              <h3 className="text-3xl mt-2">{stats.total}</h3>
            </div>
            <div className="w-12 h-12 bg-gray-100 rounded-lg flex items-center justify-center">
              <Bed className="w-6 h-6 text-gray-600" />
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Available</p>
              <h3 className="text-3xl mt-2 text-green-600">{stats.available}</h3>
            </div>
            <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
              <Check className="w-6 h-6 text-green-600" />
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Occupied</p>
              <h3 className="text-3xl mt-2 text-blue-600">{stats.occupied}</h3>
            </div>
            <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
              <Users className="w-6 h-6 text-blue-600" />
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Maintenance</p>
              <h3 className="text-3xl mt-2 text-orange-600">{stats.maintenance}</h3>
            </div>
            <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center">
              <Wrench className="w-6 h-6 text-orange-600" />
            </div>
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="bg-white p-4 rounded-xl shadow-sm border border-gray-200">
        <div className="flex items-center gap-4">
          <Filter className="w-5 h-5 text-gray-600" />
          <div className="flex gap-2 flex-wrap">
            <button
              onClick={() => setFilter('all')}
              className={`px-4 py-2 rounded-lg transition-colors ${
                filter === 'all' 
                  ? 'bg-blue-600 text-white' 
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              All Rooms
            </button>
            <button
              onClick={() => setFilter('available')}
              className={`px-4 py-2 rounded-lg transition-colors ${
                filter === 'available' 
                  ? 'bg-green-600 text-white' 
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              Available
            </button>
            <button
              onClick={() => setFilter('occupied')}
              className={`px-4 py-2 rounded-lg transition-colors ${
                filter === 'occupied' 
                  ? 'bg-blue-600 text-white' 
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              Occupied
            </button>
            <button
              onClick={() => setFilter('maintenance')}
              className={`px-4 py-2 rounded-lg transition-colors ${
                filter === 'maintenance' 
                  ? 'bg-orange-600 text-white' 
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              Maintenance
            </button>
          </div>
        </div>
      </div>

      {/* Room Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {filteredRooms.map((room) => (
          <div
            key={room.id}
            className={`bg-white p-6 rounded-xl shadow-sm border-2 transition-all hover:shadow-md ${
              room.status === 'available' ? 'border-green-200' :
              room.status === 'occupied' ? 'border-blue-200' :
              'border-orange-200'
            }`}
          >
            <div className="flex items-start justify-between mb-4">
              <div>
                <h4 className="text-xl">Room {room.id}</h4>
                <p className="text-sm text-gray-600">Floor {room.floor}</p>
              </div>
              <span className={`px-2.5 py-1 rounded-full text-xs ${
                room.status === 'available' ? 'bg-green-100 text-green-700' :
                room.status === 'occupied' ? 'bg-blue-100 text-blue-700' :
                'bg-orange-100 text-orange-700'
              }`}>
                {room.status}
              </span>
            </div>

            <div className="space-y-2 mb-4">
              <div className="flex items-center gap-2 text-sm text-gray-600">
                <Bed className="w-4 h-4" />
                {room.type}
              </div>
              <div className="flex items-center gap-2 text-sm text-gray-600">
                <Users className="w-4 h-4" />
                {room.capacity} Guests
              </div>
              <div className="flex items-center gap-2 text-sm">
                <DollarSign className="w-4 h-4" />
                ${room.price}/night
              </div>
            </div>

            {room.guest && (
              <div className="pt-3 border-t border-gray-200">
                <p className="text-xs text-gray-500">Current Guest</p>
                <p className="text-sm">{room.guest}</p>
              </div>
            )}

            {room.status === 'available' && (
              <button className="w-full mt-3 bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700 transition-colors">
                Book Room
              </button>
            )}

            {room.status === 'maintenance' && (
              <button className="w-full mt-3 bg-orange-600 text-white py-2 rounded-lg hover:bg-orange-700 transition-colors">
                Update Status
              </button>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
